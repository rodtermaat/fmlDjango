from django.apps import AppConfig


class CheckbookConfig(AppConfig):
    name = 'checkbook'
